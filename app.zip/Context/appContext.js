// Context/appContext.js
import React, { createContext, useState, useContext, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  useFonts,
  Nunito_400Regular,
  Nunito_500Medium,
  Nunito_600SemiBold,
  Nunito_700Bold,
  Nunito_800ExtraBold,
  Nunito_900Black,
} from "@expo-google-fonts/nunito";

const AppContext = createContext();

const CURRENCIES = {
  NGN: { code: "NGN", symbol: "₦", rate: 1.0,       name: "Nigerian Naira" },
  USD: { code: "USD", symbol: "$", rate: 1 / 1500,   name: "US Dollar"      },
  GBP: { code: "GBP", symbol: "£", rate: 1 / 2002,   name: "British Pound"  },
  EUR: { code: "EUR", symbol: "€", rate: 1 / 1583.4,  name: "Euro"           },
};

export { CURRENCIES };

// ─── Font weight → Nunito family name map ─────────────────────────────────────
// Use this anywhere you set fontWeight so Nunito renders correctly.
// React Native maps fontWeight to the loaded family name.
export const F = {
  regular:   "Nunito_400Regular",
  medium:    "Nunito_500Medium",
  semibold:  "Nunito_600SemiBold",
  bold:      "Nunito_700Bold",
  extrabold: "Nunito_800ExtraBold",
  black:     "Nunito_900Black",
};

export const AppProvider = ({ children }) => {
  const [darkMode, setDarkMode]         = useState(false);
  const [currencyCode, setCurrencyCode] = useState("NGN");
  const [fontsLoaded]                   = useFonts({
    Nunito_400Regular,
    Nunito_500Medium,
    Nunito_600SemiBold,
    Nunito_700Bold,
    Nunito_800ExtraBold,
    Nunito_900Black,
  });

  useEffect(() => {
    AsyncStorage.multiGet(["@revolv_dark", "@revolv_currency"]).then((pairs) => {
      if (pairs[0][1] !== null) setDarkMode(JSON.parse(pairs[0][1]));
      if (pairs[1][1] !== null) setCurrencyCode(pairs[1][1]);
    });
  }, []);

  const toggleDark = async () => {
    const next = !darkMode;
    setDarkMode(next);
    await AsyncStorage.setItem("@revolv_dark", JSON.stringify(next));
  };

  const setDarkModeCompat = (val) => {
    setDarkMode(val);
    AsyncStorage.setItem("@revolv_dark", JSON.stringify(val));
  };

  const updateCurrency = async (code) => {
    setCurrencyCode(code);
    await AsyncStorage.setItem("@revolv_currency", code);
  };

  const currency = CURRENCIES[currencyCode] ?? CURRENCIES.NGN;

  // ── Dark theme: true AMOLED black with purple accent ─────────────────────────
  const theme = darkMode
    ? {
        background: "#050507",   // near-pure black
        card:       "#0e0e14",   // slightly lifted card
        input:      "#16161f",   // input fields
        inputText:  "#e8e8f0",
        text:       "#e8e8f0",
        subText:    "#7070a0",   // muted purple-grey
        subtext:    "#7070a0",
        border:     "#1e1e2e",   // very subtle border
        iconBg:     "#16161f",
        tabBar:     "#0a0a10",
        accent:     "#a855f7",
        statusBarStyle: "light-content",
      }
    : {
        background: "#f8fafc",
        card:       "#ffffff",
        input:      "#f1f5f9",
        inputText:  "#0f172a",
        text:       "#0f172a",
        subText:    "#64748b",
        subtext:    "#64748b",
        border:     "#e2e8f0",
        iconBg:     "#f1f5f9",
        tabBar:     "#ffffff",
        accent:     "#7c5cff",
        statusBarStyle: "dark-content",
      };

  // Don't render children until fonts are ready (prevents font flash)
  if (!fontsLoaded) return null;

  return (
    <AppContext.Provider
      value={{
        darkMode,
        setDarkMode: setDarkModeCompat,
        toggleDark,
        currency,
        currencyCode,
        updateCurrency,
        CURRENCIES,
        theme,
        fontsLoaded,
        F,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => useContext(AppContext);
